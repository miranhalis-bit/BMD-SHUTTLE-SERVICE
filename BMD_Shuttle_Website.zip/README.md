# BMD GmbH Shuttle Service Website

Dies ist die offizielle Firmenwebsite für BMD GmbH Shuttle Service.

## Installation
1. Repository auf GitHub hochladen.
2. GitHub Pages aktivieren (Branch `main`, Ordner `/`).
3. Logo `logo.png` ersetzen.
4. Mailchimp-Formular-URL in `index.html` einfügen.

## Funktionen
- Leistungen anzeigen
- Buchung per Formular und E-Mail
- Kontaktformular und Google Maps
- Newsletter-Integration
- Social Media Links
- Responsives Design
